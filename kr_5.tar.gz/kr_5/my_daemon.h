#ifndef MY_DAEMON_H
#define MY_DAEMON_H

int work_daemon(char* log_file_name);

#endif
