/**
\file     schat_utilities.h
\brief    This file contains some constants for both server and client part
          of the "Simple Chat" (schat) program.
\details  It contsins predefined service messages for client-server
          interaction and global constants.
\date     14.01.2017
\author   Timofey V. Abramov
\note     For Sibers
*/


#ifndef SCHAT_UTILITIES_H
#define SCHAT_UTILITIES_H

// Maximum length of client's nickname
#define MAX_CLIENT_NAME_LENGTH 20
// Maximum number of accepted clients
#define MAX_CLIENTS_COUNT 10

// Message that means successfull operation (connection, as example)
#define SCHAT_MSG_SUCCESS "SCHAT_MSG_SUCCESS"
// Message that means fail of operation
#define SCHAT_MSG_ERROR "SCHAT_MSG_ERROR"
// Message that must send a client before it shuts down
#define SCHAT_MSG_CLOSEME "SCHAT_MSG_CLOSEME"
// Message that may send a client to get number of accepted clientsin a chat
#define SCHAT_MSG_AMOUNTOFCLIENTS_REQ "SCHAT_MSG_AMOUNTOFCLIENTS_REQ"

#endif
