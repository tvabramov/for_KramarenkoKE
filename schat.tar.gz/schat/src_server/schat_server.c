/**
\file     schat_server.c
\brief    This file contains the implementation of the server part of the
          "Simple Chat" (schat) program.
\details  From this file the "schat_server" program is compiled. After
          compilation you may start it by such command:
          ./schat_server -p 12345
          You must specify only the server's port. You may also run the
          program as:
          ./schat -h or ./schat --help
          to get additional information about launch parameters.
          When the server starts, it expects clients to be connected (10 max).
          Messages from clients are retransmitted to all other clients. 
          The server runs until turned off in the task manager.
\date     14.01.2017
\author   Timofey V. Abramov
\note     For Sibers
*/

#include <stdio.h>
#include <netdb.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <getopt.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <pthread.h>
#include <fcntl.h>
#include "schat_utilities.h"

// Used to print some service information
#define DEBUG

void init(int argc, char **argv, int *host_port);
void printHelp();
void *messages_processor(void *args);

// Structure to store client info: socket and nickname
struct ClientRec {
	int sock;					// Socket (if -1, then record is empty, not occupied)
	char name[MAX_CLIENT_NAME_LENGTH + 1];		// Name (user defined)
};

int main(int argc, char **argv)
{
	// The only input parameter
	int host_port;

	// Getting input parameter - host_port from the argv array
	init(argc, argv, &host_port);

	printf("Input data:\n\thost port = %d\n", host_port);
	
	// Creating the server's socket
	int sockfd = socket(AF_INET, SOCK_STREAM, 0);

	if (sockfd <= 0) { 
		fprintf(stderr, "Server error: socket (returned value = %d): \"%s\"\n", sockfd, strerror(errno));
		exit(EXIT_FAILURE);
	}

	// Filling the server's sockaddr_in structure
	struct sockaddr_in serv_addr;
        memset(&serv_addr, 0, sizeof(serv_addr));

	serv_addr.sin_family = AF_INET;
	serv_addr.sin_addr.s_addr = INADDR_ANY;
	serv_addr.sin_port = htons(host_port);

	// Binding serv_addr to sockfd
	if (bind(sockfd, (struct sockaddr *) &serv_addr, sizeof(serv_addr)) < 0) { 
		fprintf(stderr, "Server error: bind: \"%s\"\n", strerror(errno));
		exit(EXIT_FAILURE);
	}

	// Mark server's socket as listening, to accept incoming connection requests.
	// MAX_CLIENTS_COUNT + 1 means maximum length of the queue of
	// pending connections (we need one more than MAX_CLIENTS_COUNT to send
	// the failure message to the client that trying to connect.
	if (listen(sockfd, MAX_CLIENTS_COUNT + 1) < 0) { 
		fprintf(stderr, "Server error: listen: \"%s\"\n", strerror(errno));
		exit(EXIT_FAILURE);
	}

	// Array of ClientRec structures. At [0, ..., MAX_CLIENTS_COUNT - 1] are for potential
	// clients, and at [MAX_CLIENTS_COUNT] is for server's socket, i.e. sockfd.
	struct ClientRec clients[MAX_CLIENTS_COUNT + 1];	
	int i;
	for (i = 0; i < MAX_CLIENTS_COUNT; i++)
		clients[i].sock = -1;
	clients[MAX_CLIENTS_COUNT].sock = sockfd;
	sprintf(clients[MAX_CLIENTS_COUNT].name, "SERVER");

	// Setting socket to the non-bloking mode, for more convinient accept and read functions
        int flags = fcntl(sockfd, F_GETFL, 0);
        fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);

	// Creating the thread for clients accepting, clients' messages catching and retransmitting
	pthread_t thread_messages;
	pthread_attr_t thread_messages_attr;
        pthread_attr_init(&thread_messages_attr);
        pthread_attr_setdetachstate(&thread_messages_attr, PTHREAD_CREATE_DETACHED);
        pthread_create(&thread_messages, &thread_messages_attr, messages_processor, (void *)clients);

	// Empty loop, all work is in the threaded "messages_processor" function
	for( ; ; ) {}

	// Shutting down the sockfd
	shutdown(sockfd, SHUT_RDWR);
	close(sockfd);

	return 0;
}

/**
\brief      Fuction for the main thread, that processes accept requests and
            messages form the all clients.
\details    It contains the infinite loop, in which we with non-blocking
            "accept" and "read" functions SEQUENTLY check connection
            requests, prcess the messages from each accepted client and
            retransmit them to the other clients. It may be not very
            effective solution, but let us to avoid a large number of
            potential exceptions, and hence, additional thread
            synchronization issues.            
\param[in]  args Pointer to the ClientRec array, in which potential
            clients are located from 0 to MAX_CLIENTS_COUNT - 1, and
            server's structure is located in MAX_CLIENTS_COUNT element.
\todo       I'm not shure that non-blocking "write" functions are safe
            in this case, and if we must wait, while writing is done.
*/
void *messages_processor(void *args)
{
	// clents: [0, ..., MAX_CLIENTS_COUNT - 1] and server: [MAX_CLIENTS_COUNT], so the server is clients[MAX_CLIENTS_COUNT]
	struct ClientRec *clients = (struct ClientRec *)args;
	int ci = 0;

	for ( ; ; )
	{
		int attempt;

		// The first subloop is for accept a new client. Loop with one iteration is needed to use "break" function
		for (attempt = 0; attempt < 1; attempt++)
		{
			struct sockaddr_in cli_addr;
			socklen_t cli_addr_len = sizeof(cli_addr);

			// clients[MAX_CLIENTS_COUNT] is the server's socket
			int newsockfd = accept(clients[MAX_CLIENTS_COUNT].sock, (struct sockaddr *)&cli_addr, &cli_addr_len);

			// If there is no connections, breaking this loop
			if (newsockfd <= 0) break;

			#ifdef DEBUG
			printf("SERVER: Received connection from %s\n", inet_ntoa(cli_addr.sin_addr));
			#endif

			char data[4096];
			memset(data, 0, sizeof(char) * 4096);
			// Waithing for first message with ints nickname, that must be
			// todo: we must not wait infinitely
			while (read(newsockfd, data, sizeof(data)) <= 0) {}

			#ifdef DEBUG
			printf("Server message: I've revieved the first message from client: \"%s\"\n", data);
			#endif

			int client_id = 0;
			while ((client_id < MAX_CLIENTS_COUNT) && (clients[client_id].sock >= 0))
				client_id++;

			// Checking if there are already too many clients
			if (client_id >= MAX_CLIENTS_COUNT) {
				memset(data, 0, sizeof(char) * 4096);
				sprintf(data, SCHAT_MSG_ERROR"the connection is closed, there are too many clients for this server");
				write(newsockfd, data, strlen(data));

				shutdown(newsockfd, SHUT_RDWR);
				close(newsockfd);
				break;
			}

			// Checking if the client's nickname is too long
			if (strlen(data) > MAX_CLIENT_NAME_LENGTH) {
				memset(data, 0, sizeof(char) * 4096);
				sprintf(data, SCHAT_MSG_ERROR"the connection is closed, your nickname is too long");
				write(newsockfd, data, strlen(data));

				shutdown(newsockfd, SHUT_RDWR);
				close(newsockfd);
				break;
			}

			// Checking if the client's nickname is "SERVER"
			if (strlen(data) > MAX_CLIENT_NAME_LENGTH) {
				memset(data, 0, sizeof(char) * 4096);
                                sprintf(data, SCHAT_MSG_ERROR"the connection is closed, your nickname is unacceptable");
                                write(newsockfd, data, strlen(data));

                                shutdown(newsockfd, SHUT_RDWR);
                                close(newsockfd);
				break;
                        }

			// Creating a new record in the clients list
			clients[client_id].sock = newsockfd;
			strcpy(clients[client_id].name, data);

			// Setting socket to the non-bloking mode, for more convinient data reading
			int flags = fcntl(clients[client_id].sock, F_GETFL, 0);
			fcntl(clients[client_id].sock, F_SETFL, flags | O_NONBLOCK);

			// Sending a success message to the client
			memset(data, 0, sizeof(char) * 4096);
			sprintf(data, SCHAT_MSG_SUCCESS"connected");
			if (write(newsockfd, data, strlen(data)) <= 0) {
				fprintf(stderr, "Server error: write: \"%s\"\n", strerror(errno));
				//exit(EXIT_FAILURE);
			}
		}

		// The second subloop is to process clients' mesages
		for (ci = 0; ci < MAX_CLIENTS_COUNT; ci++)
		if (clients[ci].sock > 0)
		{
			// If we must close connection after sending answer message: 1 - true, 0 - false
			int must_close_connection = 0;
			// If we must send answer to all clients except sender (1) or only sender (0)
			int broadcast_msg = 1;

			char data[4096];
			char answer[4096];
			memset(data, 0, sizeof(char) * 4096);
			memset(answer, 0, sizeof(char) * 4096);
			// Trying to read data from clients[ci].sock
			ssize_t bytes_read = read(clients[ci].sock, data, sizeof(data));

			// There is no data right now
	                if (bytes_read <= 0) continue; //if ((bytes_read <= 0) && (errno == EAGAIN)) continue;
			// If client is gone, we prepare this message to the other clients
			else if (strstr(data, SCHAT_MSG_CLOSEME) != NULL) {
				memset(answer, 0, sizeof(char) * 4096);
				sprintf(answer, "SERVER: %s left us\n", clients[ci].name);
				must_close_connection = 1;
			}
			// If client has sent regular message to the server, we prepare this message to the other clients
			else if (strstr(data, SCHAT_MSG_AMOUNTOFCLIENTS_REQ) != NULL) {
				int k, am = 0;
				for (k = 0; k < MAX_CLIENTS_COUNT; k++)
					if (clients[k].sock > 0) am++;
				memset(answer, 0, sizeof(char) * 4096);
				sprintf(answer, "SERVER: schat clients number is: %d\n", am);
				broadcast_msg = 0; // send answer only to sender
			}
			// If client has sent regular message to the server, we prepare this message to the other clients
			else {
				memset(answer, 0, sizeof(char) * 4096);
				sprintf(answer, "%s: %s\n", clients[ci].name, data);
			}

			// Sending answer message to the other clients if broadcast is needed
			if (broadcast_msg == 1) {
				int j;
				for (j = 0; j < MAX_CLIENTS_COUNT; j++)
				if ((j != ci) && (clients[j].sock > 0)) {
					if (write(clients[j].sock, answer, strlen(answer)) <= 0) {
						fprintf(stderr, "Server error: write: \"%s\"\n", strerror(errno));
						//exit(EXIT_FAILURE);
					}
				}
			}
			// Sending private message to the sender
			else { //if (broadcast_msg == 0)
				if (write(clients[ci].sock, answer, strlen(answer)) <= 0) {
					fprintf(stderr, "Server error: write: \"%s\"\n", strerror(errno));
					//exit(EXIT_FAILURE);
				}
			}

			// Closing connection to current socket - clients[ci].sock, if we must
			if (must_close_connection > 0) {
				shutdown(clients[ci].sock, SHUT_RDWR);
				close(clients[ci].sock);

				#ifdef DEBUG
				printf("SERVER: Thread for sock = %d, number = %d, name = %s is closed\n", clients[ci].sock, ci, clients[ci].name);
				#endif

				clients[ci].sock = -1;
			        clients[ci].name[0] = '\0';

				return NULL;
			}
		}
	}
	return NULL;
}

/**
\brief      Function that initialize the startup parameters.
\details    There is only one parameter - port number. It is
            determined from the array "argv".
\param[in]  argc Amount of elements in argv array
\param[in]  argv Launch parameters
\param[out] host_port Port number
*/
void init(int argc, char **argv, int *host_port)
{
	(*host_port) = -1;

	for ( ; ; )
	{
		static int myflag;
		static struct option long_options[] =
		{
			{"help", no_argument, 0, 'h'},
			{"port", required_argument, 0, 'p'},

			{0, 0, 0, 0}
		};

		int indexptr = 0;
		int c = getopt_long(argc, argv, "hp:", long_options, &indexptr);

		if (c == -1) break;
	
		switch (c)
		{
			case 'h':
				printHelp();
				exit(EXIT_SUCCESS);
			case 'p':
				(*host_port) = atoi(optarg);
				break;
			case '?':
				fprintf(stderr, "Error: initialization error\n");
				exit(EXIT_FAILURE);
			default:
				abort();
		}
	}
	
	if (optind < argc)
	{
		fprintf(stderr, "Error: non-option ARGV-elements:");
		while (optind < argc)
			printf (" %s", argv[optind++]);
		fprintf(stderr, "\nUse \"--help\" or \"-h\" key to get help\n");
		exit(EXIT_FAILURE);
	}

	if ((*host_port) == -1)
        {
                fprintf(stderr, "Error: host port is not specified or invalid. Use \"--help\" or \"-h\" key to get help\n");
                exit(EXIT_FAILURE);
        }
}

/**
\brief      Function that prints help information.
\details    In invokes, when one type "./schat -h" or "./schat --help".
*/
void printHelp()
{
	printf("This is \"Simple Chat (schat)\" server by Timofey Abramov (timohamail@inbox.ru)\n");
	printf("Arguments:\n");
	printf("  -h --help\t\t\t\tprint help information\n");
	printf("  -p --port <number>\t\t\tspecifies the host port (mandatory option)\n");
		
	printf("Notes:\n");
	printf("  <...> - mandatory parameter\n");
	printf("  [...] - optional parameter\n");
}

