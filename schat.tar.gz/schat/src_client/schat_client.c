/**
\file     schat_client.c
\brief    This file contains the implementation of the client part of the
          "Simple Chat" (schat) program.
\details  From this file the "schat" program is compiled. After compilation
          you may start it by such command:
          ./schat -n 127.0.0.1 -p 12345 -i John_Joe 
          You must specify the server's name or ip address and port. You may
          also specify your nickname. You can start program as:
          ./schat -h or ./schat --help
          to get additional information about launch parameters.
          When your program starts, it should connect to the specified
          server and give a prompt to type commands and messages (after ">"
          symbol). To send a message to other users, just type it in this
          prompt and press "Enter". There is also command messages:
            :help - print help;
            :inc  - print incoming messages;
            :ccnt - print count of schat users;
            :exit - exit from the chat.
          This commands are typed in same manner. Since this chat is not
          exactly "real-time", you should download entering messages by
          the ":inc" command.
\date     13.01.2017
\author   Timofey V. Abramov
\note     For Sibers
\note     If your nickname contains the substring "TESTER", then
          program will run in non-interactive mode. It will send random
          messages to the server every 2 seconds during 20 seconds and then
          shut down.
*/

#include <stdio.h> 
#include <string.h> 
#include <stdlib.h> 
#include <unistd.h> 
#include <getopt.h>
#include <sys/socket.h> 
#include <sys/types.h> 
#include <netdb.h> 
#include <netinet/in.h> 
#include <arpa/inet.h>
#include <errno.h>
#include <pthread.h>
#include <fcntl.h>
#include "schat_utilities.h"

void init(int argc, char **argv, char **host_name, int *host_port, char **user_nickname);
void printHelp();
void *test_thread(void *args);

int main(int argc, char **argv)
{
	// Port number, host name (ip) and nickname - input parameters
	int host_port;
	char *host_name, *user_nickname;

	// Get its values from argv
	init(argc, argv, &host_name, &host_port, &user_nickname);

	printf("Input data:\n\thost name = %s\n\thost port = %d\n\tnick name = %s\n", host_name, host_port, user_nickname);

	// Creating socket for IPv4 communication, blocking
	int sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	
	if (sockfd <= 0) {
		fprintf(stderr, "Error: socket (returned value = %d): \"%s\"\n", sockfd, strerror(errno));
		exit(EXIT_FAILURE);
	}

	// Filling the sockaddr_in structure for connecting with schat server
	struct sockaddr_in serv_addr;

	memset(&serv_addr, 0, sizeof(serv_addr));
 	struct hostent *server = gethostbyname(host_name); 

	if (server == NULL) {
		fprintf(stderr, "Error: gethostbyname: NULL returned: %s\n", strerror(errno));
		exit(EXIT_FAILURE);
	}

	serv_addr.sin_family = AF_INET; 
	memcpy(&serv_addr.sin_addr.s_addr, server->h_addr, server->h_length); 
	serv_addr.sin_port = htons(host_port);

	// Connecting socket and sockaddr_in structure
	int connector = connect(sockfd, (const struct sockaddr *)&serv_addr, sizeof(serv_addr));
 
	if (connector < 0) {
		fprintf(stderr, "Error: connect (returned value = %d): \"%s\"\n", connector, strerror(errno));
		exit(EXIT_FAILURE);
	}

	// If we are here, connection is technically accepted

	// Here we must send to the server our nickname to register and get the confirmation message
	{
		char buffer[4096];
		memset(buffer, 0, sizeof(char) * 4096);

		sprintf(buffer, user_nickname);

		if (write(sockfd, buffer, sizeof(buffer)) <= 0) {
			fprintf(stderr, "Error: write: \"%s\"\n", strerror(errno));
			exit(EXIT_FAILURE);
		}

		memset(buffer, 0, sizeof(char) * 4096);

		if (read(sockfd, buffer, sizeof(buffer)) <= 0) {
			fprintf(stderr, "Error: read: \"%s\"\n", strerror(errno));
			exit(EXIT_FAILURE);
		}

		if (strstr(buffer, SCHAT_MSG_SUCCESS) == NULL) {
			fprintf(stderr, "Error: server's answer is not \""SCHAT_MSG_SUCCESS"\", but \"%s\"\n", buffer);
			exit(EXIT_FAILURE);
		}
        }

	// If we are here, connection is totally accepted
	printf("CLIENT(%s): made a connection to %s\n", user_nickname, inet_ntoa(serv_addr.sin_addr));

	// Some code for testing. if user's nickname contains "TESTER", it just runs a tester thread and waits
	if (strstr(user_nickname, "TESTER") != NULL)
	{
		pthread_t thread;
		pthread_attr_t thread_attr;
		pthread_attr_init(&thread_attr);
		pthread_attr_setdetachstate(&thread_attr, PTHREAD_CREATE_DETACHED);
		pthread_create(&thread, &thread_attr, test_thread, (void *)&sockfd);

		sleep(20);

		char buffer[4096];
		memset(buffer, 0, sizeof(char) * 4096);

		sprintf(buffer, SCHAT_MSG_CLOSEME);

		if (write(sockfd, buffer, sizeof(buffer)) <= 0) {
			fprintf(stderr, "Error: read: \"%s\"\n", strerror(errno));
			exit(EXIT_FAILURE);
		}

		return 0;
	}	

	//setting socket to the non-bloking mode, for more convinient data reading
	int flags = fcntl(sockfd, F_GETFL, 0);
	fcntl(sockfd, F_SETFL, flags | O_NONBLOCK);

	// Main loop for catching user's commands
	for ( ; ; )
	{
		char mymsg[4096];
		memset(mymsg, 0, sizeof(char) * 4096);

		printf("> ");
		fgets(mymsg, 4095, stdin);

		// Trim the string
		while ((strlen(mymsg) > 0) && ((mymsg[strlen(mymsg) - 1] == '\r') || (mymsg[strlen(mymsg) - 1] == '\n')))
			mymsg[strlen(mymsg) - 1] = '\0';
		
		// Chenking for command ":help" - print prompt help 
		if (strcmp(mymsg, ":help") == 0)
		{
			printf("\t:help - print help;\n\t:inc  - print incoming messages;\n\t:ccnt - print count of schat users;\n\t:exit - exit from the chat.\n");
			continue;
		}
		// Chenking for command ":exit" - shut down application
		else if (strcmp(mymsg, ":exit") == 0) break;
		// Chenking for command ":inc" - getting incoming messages
		else if (strcmp(mymsg, ":inc") == 0)
		{
			char data[4096];
			memset(data, 0, sizeof(char) * 4096);

			ssize_t bytes_read = read(sockfd, data, sizeof(data));

			// there is no data
			if (bytes_read <= 0) continue;//if ((bytes_read <= 0) && (errno == EAGAIN)) continue;

			printf("%s", data);
		
			continue;	
		}
		else if (strcmp(mymsg, ":ccnt") == 0)
		{
			memset(mymsg, 0, sizeof(char) * 4096);
			sprintf(mymsg, SCHAT_MSG_AMOUNTOFCLIENTS_REQ);
		}

		if (strlen(mymsg) > 0)
			if (write(sockfd, mymsg, strlen(mymsg)) <= 0) {
        	        	fprintf(stderr, "Error: write: \"%s\"\n", strerror(errno));
                	        exit(EXIT_FAILURE);
			}
	}
	
	// Sending message to the server, that we are leaving the chat
	char buffer[4096];
	memset(buffer, 0, sizeof(char) * 4096);

	sprintf(buffer, SCHAT_MSG_CLOSEME);
	ssize_t bytes_written = write(sockfd, buffer, sizeof(buffer));
	if (bytes_written == 0) {
		fprintf(stderr, "Error: write: \"%s\"\n", strerror(errno));
		exit(EXIT_FAILURE);
        }

	// Shut down the connection
	shutdown(sockfd, SHUT_RDWR);
	close(sockfd);

//printf("Client %s is closed\n", user_nickname);

	// Free memory
	free(host_name);
	free(user_nickname);

	return 0;
}

/**
\brief      Thread function for testing.
\details    If nickname contains the substring "TESTER", program runs this
            function in the thread. It sends random messages to the server
            every 2 seconds.
\param[in]  args Pointer to the socket (int)
*/
void *test_thread(void *args)
{
	int sock = *(int *)args;

	for ( ; ; )
	{
		char buffer[4096];
		memset(buffer, 0, sizeof(char) * 4096);

		sprintf(buffer, "test_message_%d", rand() % 100);

		if (write(sock, buffer, strlen(buffer)) <= 0) {
                        fprintf(stderr, "Error: write: \"%s\"\n", strerror(errno));
                        exit(EXIT_FAILURE);
                }

		sleep(2);
	}

	return NULL;
}

/**
\brief      Function that initialize the startup parameters.
\details    There are three parameters - sever's name (or ip), port
            and user's nickname (optional). They are determined from
            the array "argv".
\param[in]  argc Amount of elements in argv array
\param[in]  argv Launch parameters
\param[out] host_name Name or ip address of host (server)
\param[out] host_port Port number
\param[out] user_nickname User-defined nickname, which will be displayed in the chat
*/
void init(int argc, char **argv, char **host_name, int *host_port, char **user_nickname)
{
	(*host_name) = NULL;
	(*host_port) = -1;
	(*user_nickname) = NULL;

	for ( ; ; )
	{
		static int myflag;
		static struct option long_options[] =
		{
			{"help", no_argument, 0, 'h'},
			{"host-name", required_argument, 0, 'n'},
			{"port", required_argument, 0, 'p'},
			{"nick-name", required_argument, 0, 'i'},

			{0, 0, 0, 0}
		};

		int indexptr = 0;
		int c = getopt_long(argc, argv, "hn:p:i:", long_options, &indexptr);

		if (c == -1) break;
	
		switch (c)
		{
			case 'h':
				printHelp();
				exit(EXIT_SUCCESS);
			case 'n':
				(*host_name) = (char*)malloc(sizeof(char) * (strlen(optarg) + 1));
				strcpy((*host_name), optarg);
				break;
			case 'p':
				(*host_port) = atoi(optarg);
				break;
			case 'i':
                                (*user_nickname) = (char*)malloc(sizeof(char) * (strlen(optarg) + 1));
				strcpy((*user_nickname), optarg);
                                break;
			case '?':
				fprintf(stderr, "Error: initialization error\n");
				exit(EXIT_FAILURE);
			default:
				abort();
		}
	}
	
	if (optind < argc)
	{
		fprintf(stderr, "Error: non-option ARGV-elements:");
		while (optind < argc)
			printf (" %s", argv[optind++]);
		fprintf(stderr, "\nUse \"--help\" or \"-h\" key to get help\n");
		exit(EXIT_FAILURE);
	}

	if ((*host_name) == NULL)
	{
		fprintf(stderr, "Error: host name is not specified. Use \"--help\" or \"-h\" key to get help\n");
                exit(EXIT_FAILURE);
	}

	if ((*host_port) == -1)
        {
                fprintf(stderr, "Error: host port is not specified or invalid. Use \"--help\" or \"-h\" key to get help\n");
                exit(EXIT_FAILURE);
        }

	if ((*user_nickname) == NULL)
        {
		(*user_nickname) = (char*)malloc(sizeof(char) * (strlen("Anonymous") + 1));
		sprintf((*user_nickname), "Anonymous");
	}
}

/**
\brief      Function that prints help information.
\details    In invokes, when one type "./schat -h" or "./schat --help".
*/
void printHelp()
{
	printf("This is \"Simple Chat (schat)\" client by Timofey Abramov (timohamail@inbox.ru)\n");
	printf("Arguments:\n");
	printf("  -h --help\t\t\t\tprint help information\n");
	printf("  -n --host-name <text>\t\t\tspecify either the server's host name or the ip address (mandatory option)\n");
	printf("  -p --port <number>\t\t\tspecifies the server's host port (mandatory option)\n");
	printf("  -i --nick-name <text>\t\t\tspecify your nickname in the chat. \"Anonymous\" is default (optional)\n");
	printf("Notes:\n");
	printf("  <...> - mandatory parameter\n");
	printf("  [...] - optional parameter\n");
}
